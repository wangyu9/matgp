To test the pre-compiled 64bit executable just double-click on the "MeshFix.exe" icon.
If Windows cannot execute it (e.g. because of a missing DLL) you probably need to install Microsoft Visual C++ 2013 Redistributable Package for x64.
You can download it at:
https://www.microsoft.com/en-US/download/details.aspx?id=40784

