function [ y ] = perpdot( x )
%PERPDOT Summary of this function goes here
%   Detailed explanation goes here
y = [-x(2),x(1)];
