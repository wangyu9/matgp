%% Load a mesh

[X, T] = readOff('395.off');

%% Compute LB eigenstuff

nEigs = 100;
FEM = firstOrderFEM(X,T); % set up FEM matrices
[evecs,evals] = eigs(FEM.laplacian,FEM.vtxInnerProds,nEigs,'sm'); %original test was 300
evals = diag(evals);

%% Design distributions as centered around points for testing

point0 = 1779; %nose
point1 = 7943; %tail

% Construct extrinsic Gaussians around these two points
a0 = 50; % determines standard deviation
a1 = 50;

dist0 = sqrt(sum(bsxfun(@minus,X,X(point0,:)).^2,2));
rho0 = exp(-dist0.^2*a0);
rho0 = rho0/sum(rho0);
showDescriptor(X,T,rho0); % displays mesh with a function on vertices
title('Rho 0');

dist1 = sqrt(sum(bsxfun(@minus,X,X(point1,:)).^2,2));
rho1 = exp(-dist1.^2*a1);
rho1 = rho1/sum(rho1);
showDescriptor(X,T,rho1);
title('Rho 1');

%% Precompute quantities that can be useful for multiple EMD computations

structure = precomputeEarthMoversADMM(X, T, evecs(:,2:end));

%% Compute EMD

[distance,J] = earthMoversADMM(X, T, rho0, rho1, structure);
fprintf('EMD = %g\n',distance);

%% Display momentum field

showFaceVectorField(X, T, J{1});
title('Momentum vector field');